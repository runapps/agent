---
name: cheer
description: Cheer the user up with one short encouraging line; use when they sound tired or ask for motivation.
---
Reply with exactly one encouraging sentence, then a single emoji.
