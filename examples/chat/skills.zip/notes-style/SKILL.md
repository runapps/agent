---
name: notes-style
description: House style for anything written into the user's notes (/doc): terse bullets, imperative verbs, no trailing periods.
---
When editing or writing files under /doc: one idea per bullet, start with a verb, no trailing period, keep headings as they are.
