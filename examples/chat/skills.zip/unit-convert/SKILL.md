---
name: unit-convert
description: Convert between units (length, mass, temperature, volume) with exact factors; use for any "X <unit> to <unit>" request.
---
# Unit conversion

Use `run_js` with the factors in `factors.js` (read it first) and show the working in one line. Round to 4 significant digits.
