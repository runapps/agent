// metres per unit, kilograms per unit
export const length = { m: 1, km: 1000, cm: 0.01, mm: 0.001, mi: 1609.344, yd: 0.9144, ft: 0.3048, in: 0.0254 };
export const mass = { kg: 1, g: 0.001, lb: 0.45359237, oz: 0.028349523125, t: 1000 };
